<div class="container-fluid dashboard-content ">
    <div class="row">

        <main role="main" class="col-md-9 ml-sm-auto col-lg-12 px-md-4">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h2 class="card-header">Store</h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <div class="btn-group mr-2">
                                    <div class="float-right"><a href="javascript:void(0);" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#FormModal"><span class="fa fa-plus"></span> Tambah Data</a></div>
                                    <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                                </div>
                            </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Store</th>
                                        <th>Alamat Store</th>
                                        <th>No Telepon</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="tblstore">
                                    <!--  disini nanti akan muncul tabel yang dikirim dari coding ajax pada javascript
            sehingga tbody di berikan ID agar tidak salah saat pengiriman data 
          sama seperti primarykey agar tidak salah alamat
          -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<!-- MODAL ADD di Ubah Menajadi FormModal pada id nya tujuannya agar form ini dapat digunakan untuk input dan update-->
<form>
    <div class="modal fade" id="FormModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Form Input Store</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!--  Paste disini -->
                    <input type="hidden" class="form-control" name="idstore" id="idstore" value="">
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">Nama Store</label>
                        <input type="text" class="form-control" name="namastore" id="namastore" aria-describedby="emailHelp" placeholder="Enter Name Store">
                    </div>
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">Alamat Store</label>
                        <input type="text" class="form-control" name="addressstore" id="addressstore" aria-describedby="emailHelp" placeholder="Enter Alamat Store">
                    </div>
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">No Telepon</label>
                        <input type="text" class="form-control" name="telpstore" id="telpstore" aria-describedby="emailHelp" placeholder="Enter No Telepon">
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="btn_close">Close</button>
                    <div id="divsave"><button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button></div>
                    <div id="divupdate"></div>

                    <!--Perhatikan divsave dan divupdate diatas
                      tujuannya agar ketika akan menggunakan form input button simpan dinamakan Save sedangkan untuk edit menjadi
                      button update
                      implementasi ada di java script di klik edit , btn_update dan btn_close-->
                </div>
            </div>
        </div>
    </div>
</form>
<!--END MODAL ADD-->

<!--MODAL DELETE ini untuk konfirmasi , agar ketika klik delete tidak langsung terhapus-->
<form>
    <div class="modal fade" id="Modal_Delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Store</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <strong>Are you sure to delete this record?</strong>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="idstore_delete" id="idstore_delete" class="form-control">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="button" type="submit" id="btn_delete" class="btn btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
</form>
<!--END MODAL DELETE-->

<script type="text/javascript">
    $(document).ready(function() {

        show_store(); //memanggil function yang ada di bawah
        //
        //
        //artinya yang ada pada bagian ini untuk mengeksekusi fuction apapun
        //
        //
        function show_store() { //untuk menampilkan data product
            $.ajax({
                type: 'GET',
                url: '<?php echo site_url('Store/getStore') ?>', //Memanggil Controller/Function
                async: false,
                dataType: 'json',
                success: function(data) {
                    var html = '';
                    var i;
                    var no;
                    for (i = 0; i < data.length; i++) { //looping atau pengulangan
                        no = i + 1;
                        html += '<tr>' +
                            '<td>' + no + '</td>' +
                            '<td>' + data[i].name_store + '</td>' +
                            '<td>' + data[i].address_store + '</td>' +
                            '<td>' + data[i].telp_store + '</td>' +
                            '<td style="text-align:center;">' +
                            '<a href="javascript:void(0);" class="btn btn-info btn-sm item_edit" data-idstore="' + data[i].id_store + '"><i class="fas fa-pencil-alt"></i></a>' + ' ' +
                            '<a href="javascript:void(0);" class="btn btn-danger btn-sm item_delete" data-idstore="' + data[i].id_store + '"><i class="fas fa-trash"></i></a>' +
                            '</td>' +
                            '</tr>';
                    } // akhir dari looping

                    $('#tblstore').html(html); // mengirim data
                }
            });
        }

        //Save product
        $('#btn_save').on('click', function() {
            var namastore = $('#namastore').val(); //deklarasi variabel $('#id yang digunakan pada textbox')
            var addressstore = $('#addressstore').val();
            var telpstore = $('#telpstore').val();

            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Store/save') ?>", //Memanggil Controller/Function
                dataType: "JSON",
                data: {
                    namastore: namastore,
                    addressstore: addressstore,
                    telpstore: telpstore

                }, // menampung seluruh variable menjadi array
                success: function(data) { // setelah di simpan sudah seharusnya textbox yang diisi menjadi kosong
                    $('[name="namastore"]').val(""); // sehingga untuk mengosongkannya dengan cara berikut
                    $('[name="addressstore"]').val(""); //.val() untuk mengatur value yg ada di textbox
                    $('[name="telpstore"]').val("");
                    $('#FormModal').modal('hide');
                    show_store(); // setelah disimpan tentunya harus di refresh di tampilkan kembali data terbaru 
                    // maka function ini kembali di panggil
                }
            });
            return false;
        });

        //Edit Data
		$('#tblstore').on('click', '.item_edit', function() {
			var idstore = $(this).data('idstore'); // variabel ini diambil dari data yg ada pada tabel 
			// silahkan perhartikan pada attribut  data-idproduct="'+dataXXXXX data-idproduct harus sama dengan .data('idproduct')
			// data-idproduct sebagai pengirim dan  $(this).data('idproduct');  sebagai penerima
			var btnupdate = '<button type="button" type="submit" id="btn_update" class="btn btn-primary">Update</button>';
			// deklarasi variable untuk menampilkan button Update
			$('#FormModal').modal('show'); //menampilkan formModal
			$('#divsave').html(""); // menyembunyikan button save
			$('#divupdate').html(btnupdate); // mengirim ke divupdate untuk di tampilkan
			$.ajax({
				type: 'POST',
				url: '<?php echo site_url('Store/editStore') ?>', //Memanggil Controller/Function
				async: false,
				dataType: 'json',
				data: {
					idstore: idstore
				},
				success: function(data) { //maka akan didapatkan data dari hasil pemanggilan controller di parsing menjadi JSON
					$('[name="idstore"]').val(data[0].id_store);
					$('[name="namastore"]').val(data[0].name_store);
					$('[name="addressstore"]').val(data[0].address_store);
                    $('[name="telpstore"]').val(data[0].telp_store);
				}
			});
		});

		$('#divupdate').on('click', function() {
			var idstore = $('#idstore').val(); //mendeklarasikan data seperti pada button save
			var namastore = $('#namastore').val();
			var addressstore = $('#addressstore').val();
            var telpstore = $('#telpstore').val();
			$('#divsave').html('<button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button>');
			//setelah button update digunakan maka button update akan hilang dan diganti dengan button save
			$('#divupdate').html("");
			$.ajax({
				type: "POST",
				url: "<?php echo site_url('Store/updateStore') ?>", // mengirim data yang di update
				dataType: "JSON",
				data: {
                    idstore: idstore,
					namastore: namastore,
					addressstore: addressstore,
                    telpstore: telpstore
				}, // data2 yang akan diupdate
				success: function(data) {
                    $('[name="idstore"]').val("");
                    $('[name="namastore"]').val(""); // sehingga untuk mengosongkannya dengan cara berikut
                    $('[name="addressstore"]').val(""); //.val() untuk mengatur value yg ada di textbox
                    $('[name="telpstore"]').val("");
                    $('#FormModal').modal('hide');
                    show_store();// ditampilkan kembali data dengan memanggi functionnya
				}
			});
			return false;
		});


        $('#btn_close').on('click', function() { //sudah di jelaskan sebelumnya diatas , maka pada form modal jika tidak mengisi form alias close maka tentu data semua harus kosong baik input ataupun update
            $('[name="idstore"]').val("");
            $('[name="namastore"]').val("");
            $('[name="addressstore"]').val("");
            $('[name="telpstore"]').val("");
            $('#FormModal').modal('hide');
            $('#divsave').html('<button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button>');
            $('#divupdate').html("");
        });

        $('#tblstore').on('click', '.item_delete', function() {
            var idstore = $(this).data('idstore'); // sama seperti edit hanya silahkan cek ke atas

            $('#Modal_Delete').modal('show'); //menampilkan modal delete atau pop up delete
            $('[name="idstore_delete"]').val(idstore);
        });

        //delete record to database
        $('#btn_delete').on('click', function() {
            var idstore = $('#idstore_delete').val(); //deklarasi
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Store/delete') ?>", //memanggil contrroller/function
                dataType: "JSON",
                data: {
                    idstore: idstore
                }, //data yang dikirim untuk menghapus
                success: function(data) {
                    $('[name="idstore"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_store(); // setelah di hapus pastinya ditampilkan kembali data yang terbaru
                }
            });
            return false;
        });

    });
</script>