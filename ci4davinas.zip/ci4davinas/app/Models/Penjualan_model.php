<?php

namespace App\Models;

use CodeIgniter\Model;

class Penjualan_model extends Model
{
    protected $table = 'customers';

    public function getSell()
    {
        $builder = $this->db->table('sell');
        $builder->select('*');
        return $builder->get();
    }
    public function saveSell($data)
    {
        $query = $this->db->table('sell')->insert($data);
        return $query;
    }
    public function saveDetailSell($data)
    {
        $query = $this->db->table('sell_detail')->insert($data);
        return $query;
    }
    public function laporanSell($awal, $akhir)
    {
        $builder = $this->db->table('sell'); // menentukan tabel
        $builder->select('*'); // menentukan colom
        $builder->where('tgl_sell >=', $awal);
        $builder->where('tgl_sell <=', $akhir);
        $query = $builder->get(); // untuk eksekusi
        return $query;
    }
}
